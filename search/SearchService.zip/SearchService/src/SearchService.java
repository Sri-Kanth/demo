import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;

import com.xyz.demo.connector.search.Driver;


@Path("/search")
public class SearchService {
 
 
	  @Path("{f}")
	  @GET
	  @Produces("application/json")
	  public Response convertFtoCfromInput(@PathParam("f") String query) throws JSONException {
 
		JSONObject jsonObject = new JSONObject();
		
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(1);
		
		Driver searchInvoker = new Driver(query);
		
		Future searchResult = executor.submit(searchInvoker);
		
		String result = "@Produces(\"application/json\") Output: \n\nF to C Converter Output: \n\n" + searchResult;
		
		return Response.status(200).entity(result).build();
	  }
}