package com.xyz.demo.connector.search;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;

public class YahooCallable implements Callable<List<String>> {
	private String searchString = null;

	public YahooCallable(String query) {
		this.searchString = query;
	}

	@Override
	public List<String> call() throws Exception {
		return Collections.EMPTY_LIST;
	}
}
