package com.xyz.demo.connector.search;

public class SearchRequestor {

}
