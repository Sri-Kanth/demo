package com.xyz.demo.connector.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class Driver implements Callable<Map> {
	
	private String query;
	
	public Driver(String queryString) {
		this.query = queryString;
	}
	@Override
	public Map call() throws Exception {
		return searchAll(query);
	}
	
	private Map<String, List<String>> searchAll(String searchquery) {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(3);
		
		Map<String, List<String>> combinedResults = new HashMap<String, List<String>>();
		
		
		List<Future<List<String>>> searchLists = new ArrayList<Future<List<String>>>();
		
		BingCallable bing = new BingCallable(searchquery);
		
		GoogleCallable goog = new GoogleCallable(searchquery);
		
		YahooCallable yahoo = new YahooCallable(searchquery);
		
		Future<List<String>> bingresp = executor.submit(bing);
		Future<List<String>> googresp = executor.submit(goog);
		Future<List<String>> yahooresp = executor.submit(yahoo);
		
		searchLists.add(bingresp);
		searchLists.add(googresp);
		searchLists.add(yahooresp);
		
		for(Future<List<String>> future : searchLists)
        {
              try
              {
                  System.out.println("Future result is - " + " - " + future.get() + "; And Task done is " + future.isDone());
                  
                  combinedResults.put("source", future.get());
              }
              catch (InterruptedException | ExecutionException e)
              {
                  e.printStackTrace();
              }
          }
		
		executor.shutdown();
		
		return combinedResults;
	}

}
