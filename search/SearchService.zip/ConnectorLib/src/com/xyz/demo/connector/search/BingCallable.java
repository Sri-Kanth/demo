package com.xyz.demo.connector.search;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BingCallable implements Callable<List<String>> {
	
	private String searchString = null;
	
	public BingCallable(String query) {
		this.searchString = query;
	}

	public List<String> call() throws Exception {
		List<String> results = Collections.EMPTY_LIST;
		
		Document doc;
		try {
			
			int numberofpages = 5;
			
			doc = Jsoup.connect("http://www.bing.com/search?q="+URLEncoder.encode(searchString, "utf-8")+"&go=Submit&qs=n&form=QBLH&pq=executor&sc=8-8&sp=-1&sk=&cvid=cec3ea108b9d44339667afc264fb3531").get();
			
			List<Element> allresults = new ArrayList<Element>();
			
			Elements newsHeadlines = doc.select("#b_results .b_algo h2 a");
			
			
			allresults.addAll(newsHeadlines);
			
			
			Elements links = doc.select(".b_pag li a");
			
			for(Element link:links) {
				if(link.attr("href") != null && link.attr("href").length() > 0) {
					
					System.out.println(link.attr("href"));
					
					
					allresults.addAll(fetchResults(link.attr("href")));
				}
			}
			
			System.out.println(allresults.size());
			
			for(Element result:allresults) {
				results.add(result.toString());
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return results;
	}

	private String urlbase = "http://www.bing.com";

	private List<Element> fetchResults(String url) {
		List<Element> results = Collections.EMPTY_LIST;

		try {
			Document doc = Jsoup.connect(urlbase + url).get();

			results = doc.select("#b_results .b_algo h2 a");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return results;

	}
}
