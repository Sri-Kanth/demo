package com.xyz.demo.connector.search;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;

public class GoogleCallable implements Callable<List<String>> {

	private String searchString = null;
	
	public GoogleCallable(String query) {
		this.searchString = query;
	}
	
	
	@Override
	public List<String> call() throws Exception {
		
		return Collections.EMPTY_LIST;
	}
	
	

}
