import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.print.Doc;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.Test;


public class TestInvoke {

	@Test
	public void test() {
		
		Document doc;
		try {
			
			int numberofpages = 5;
			
			String searchString = "how to write java code";
			doc = Jsoup.connect("http://www.bing.com/search?q="+URLEncoder.encode(searchString, "utf-8")+"&go=Submit&qs=n&form=QBLH&pq=executor&sc=8-8&sp=-1&sk=&cvid=cec3ea108b9d44339667afc264fb3531").get();
			
			List allresults = new ArrayList<Element>();
			
			Elements newsHeadlines = doc.select("#b_results .b_algo h2 a");
			
			
			allresults.addAll(newsHeadlines);
			
			System.out.println(newsHeadlines.get(0).toString());
			
			Elements links = doc.select(".b_pag li a");
			
			for(Element link:links) {
				if(link.attr("href") != null && link.attr("href").length() > 0) {
					
					System.out.println(link.attr("href"));
					
					
					allresults.addAll(fetchResults(link.attr("href")));
				}
			}
			
			System.out.println(allresults.size());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private String urlbase = "http://www.bing.com";
	
	private List<Element> fetchResults(String url) {
		List<Element> results = Collections.EMPTY_LIST;
		
		try {
			Document doc = Jsoup.connect(urlbase + url).get();
			
			results = doc.select("#b_results .b_algo h2 a");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return results;
		
	}

}
